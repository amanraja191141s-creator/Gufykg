# Micro-level audit — v98.63.9.31

## Video reference comparison
Reviewed screen recordings dated 2026-11-22 at 08:26 and 09:43. Reference shows a four-column scientific function bank, pink panel, fixed row ordering, no plus control per previous explicit request, and inverse state changing applicable labels.

## Changes
- Replaced the prior scientific grid with the video row arrangement: INV/sin/cos/tan; sinh/cosh/tanh/i; sinh⁻¹/cosh⁻¹/tanh⁻¹/∛; 2ˣ/x³/x⁻ʸ/empty.
- INV is wired to sin↔asin, cos↔acos, tan↔atan, 2ˣ↔10ˣ, x³↔x², x⁻ʸ↔xʸ. Hyperbolic and inverse-hyperbolic rows remain visible as shown in reference.
- Kept 20px minimum key labels and existing 20px reduction of the basic keypad surface while scientific overlay is open.
- Removed the More/+ affordance; last cell remains an inert empty grid cell to preserve matrix alignment.
- Version, web mirrors, service-worker cache, Android workflow and regression test updated.

## Scope and limitations
Static source review and automated tests are not a physical Android test. Touch timing, rendering differences across WebView versions, and actual APK build remain unverified until GitHub Actions/device execution.
