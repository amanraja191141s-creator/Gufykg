# Changelog — v98.63.9.22

## Physical UI repair from the 21 Nov 2026 screen recording
- Fixed Other Calculator cards collapsing labels into one-character vertical stacks.
- Reasserted a responsive three-column tile grid with centered icon-over-label hierarchy.
- Prevented character-level wrapping and capped labels at two readable lines.
- Made all four tool groups reachable through vertical scrolling; preserved all 16 destinations.
- Widened the scientific keypad drawer to 94vw and increased function-key touch targets to at least 48px.
- Rebalanced the 4×4 scientific function matrix and the More-functions grid for phone widths.
- Kept scientific expression engine, inverse modifier, angle mode, memory, history and main calculator keypad behavior intact.
- Synchronized package, manifest, HTML, app, service-worker and Android workflow release identities.
