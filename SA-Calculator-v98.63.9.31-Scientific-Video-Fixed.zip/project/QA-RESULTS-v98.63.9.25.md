# QA results — v98.63.9.25

## Automated verification
- Release regression suite: **53/53 passed, 0 failed**.
- `npm run build:web`: passed; 13 required Android web assets verified.
- JavaScript syntax: passed for app runtime, service worker and Android build scripts.
- Workflow YAML: parsed successfully with PyYAML.
- Release identity: package, HTML, runtime, PWA manifest and Android workflow synchronized.
- Android `versionCode`: `1098073`.
- HTML ID audit: 274 IDs, no duplicates.

## Interaction coverage
- Scientific plus control opens the additional-functions layer and changes to a close glyph.
- Toggle restores plus glyph and accessible label when closed.
- Escape closes the expanded functions before closing the drawer.
- Escape from the scientific expression editor does not clear the expression while the additional-functions layer is open.
- Drawer close resets expanded state.
- Expanded functions remain flat, pink, text-only and free of extra headings/cards/helper labels.

## Not claimed
A hosted GitHub Actions Gradle build, APK installation, physical Android rendering, OEM gesture behavior, touch latency and frame pacing were not run in this local environment. The supplied workflow performs the APK build and package identity verification when run in GitHub Actions.
