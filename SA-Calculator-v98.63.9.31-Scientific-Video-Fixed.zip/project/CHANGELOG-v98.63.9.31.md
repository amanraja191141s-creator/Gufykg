# Changelog v98.63.9.31

Scientific panel reference correction: row layout changed to trig/hyperbolic/inverse-hyperbolic/power matrix; INV mappings extended to all paired trig/power keys; floating More/+ removed; 20px scientific label floor and basic keypad -20px geometry retained; web mirror and cache/version/workflow metadata refreshed.
