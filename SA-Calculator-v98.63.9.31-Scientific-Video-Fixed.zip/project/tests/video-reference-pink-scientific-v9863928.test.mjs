import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const patch=css.slice(css.lastIndexOf('v98.63.9.28 — scientific keypad primary matrix matches the supplied pink reference'));
test('primary scientific matrix uses the exact 4x4 reference labels and order',()=>{
 const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
 const labels=[...grid.matchAll(/<button[^>]*>([^<]*)<\/button>/g)].map(m=>m[1]);
 assert.deepEqual(labels,['INV','sin','cos','tan','ln','log','|x|','x!','π','e','eˣ','√','10ˣ','x²','xʸ','＋']);
 assert.equal((grid.match(/<button\b/g)||[]).length,16);
});
test('INV switches only the sine cosine tangent labels and tokens, one-shot behavior remains',()=>{
 const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
 for(const [normal,inverse] of [['sin(','asin('],['cos(','acos('],['tan(','atan(']]){
  assert.ok(grid.includes(`data-sci-insert="${normal}"`)); assert.ok(grid.includes(`data-sci-alt-insert="${inverse}"`));
 }
 assert.match(js,/if \(shiftActive && key\.dataset\.sciAltInsert\)/);
});
test('reference pink panel has unclipped unboxed labels, circular INV and dark circular plus',()=>{
 assert.match(patch,/height:56%!important/); assert.match(patch,/background:#ff4b91!important/);
 assert.match(patch,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(patch,/grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.ok(patch.includes('scientific-function-grid > #sci-shift-toggle[aria-pressed="true"]'));
 assert.match(patch,/scientific-function-grid > #sci-more-toggle/); assert.match(patch,/background:#29262d!important/);
 assert.match(patch,/scientific-function-grid > button::before \{display:none!important;content:none!important\}/);
});
test('more-functions stays a functional 4x4 secondary panel and remains accessible',()=>{
 const panel=html.match(/<div class="scientific-more-functions"[\s\S]*?<\/div>/)?.[0]||'';
 for(const f of ['sinh(','cosh(','tanh(','asinh(','acosh(','atanh(','cbrt(','2^(','^(-','log2(','i']) assert.ok(panel.includes(`data-sci-insert="${f}"`),f);
 assert.match(panel,/id="sci-more-page-close"/); assert.match(js,/expanded\?'Close additional scientific functions':'More scientific functions'/);
});
test('release package identity is synchronized for .28',()=>{
 assert.equal(pkg.version,'1.98.76-v98.63.9.29'); assert.equal(pkg.androidVersionCode,1098077);
 assert.match(html,/1\.98\.76-v98\.63\.9\.29/); assert.match(js,/APP_VERSION = '1\.98\.76-v98\.63\.9\.29'/);
});
