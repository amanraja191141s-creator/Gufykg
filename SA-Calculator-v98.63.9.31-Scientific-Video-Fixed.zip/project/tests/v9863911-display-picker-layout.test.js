const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('v98.63.9.11 gives the calculator display the marked upper workspace and keypad the remaining height', () => {
  assert.match(css, /#screen-calc\.active > \.calc-display\s*\{[\s\S]*?flex:0 0 46%/);
  assert.match(css, /#screen-calc\.active > \.main-keypad\s*\{[\s\S]*?flex:1 1 54%/);
  assert.match(css, /grid-template-rows:repeat\(5,minmax\(0,1fr\)\)/);
  assert.match(css, /overflow-x:auto!important/);
  assert.match(html, /id="calc-expr"/);
  assert.match(html, /id="calc-val"/);
});

test('v98.63.9.16 currency and unit selectors show all options before optional search', () => {
  assert.match(js, /Every enabled option is present on first open/);
  assert.doesNotMatch(js, /revealAlternatives/);
  assert.doesNotMatch(js, /query\.length < 2 && index !== selectedIndex/);
  assert.match(js, /const isCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /const isUnit = \/\^unit-\(from\|to\)\$\//);
});

test('v98.63.9.11 browser and Android WebView assets are identical', () => {
  for (const file of ['assets/css/app.css', 'assets/js/app.js']) {
    assert.equal(fs.readFileSync(path.join(root, file), 'utf8'), fs.readFileSync(path.join(root, 'www', file), 'utf8'));
  }
});
